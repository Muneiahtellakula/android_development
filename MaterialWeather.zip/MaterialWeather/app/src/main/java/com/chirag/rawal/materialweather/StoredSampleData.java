package com.chirag.rawal.materialweather;

public class StoredSampleData {
    public String cityName;
    public Integer cityID;

    public StoredSampleData(String cityName, Integer cityID) {
        this.cityName = cityName;
        this.cityID = cityID;
    }
}
