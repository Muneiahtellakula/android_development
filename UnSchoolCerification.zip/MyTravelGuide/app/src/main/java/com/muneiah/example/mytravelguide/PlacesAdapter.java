package com.muneiah.example.mytravelguide;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PlacesAdapter extends RecyclerView.Adapter<PlacesAdapter.PlaceViewHolder> {
    Context ctx;
    String address[];
    int imgg[];
    String event_nam[];

    public PlacesAdapter(Context ctx, String[] address, int[] imgg, String[] event_name) {
        this.ctx = ctx;
        this.address = address;
        this.imgg = imgg;
        this.event_nam = event_name;
    }

    @NonNull
    @Override
    public PlaceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new PlaceViewHolder(LayoutInflater.from(ctx).inflate(R.layout.event_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull PlaceViewHolder holder, int position) {
        //holder.event_add.setText("Address :"+address[position]);
        holder.imageView_event.setImageResource(imgg[position]);
        holder.event_name.setText(event_nam[position]);
    }

    @Override
    public int getItemCount() {
        return event_nam.length;
    }

    public class PlaceViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView_event;
        TextView event_add, event_name;

        public PlaceViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView_event = itemView.findViewById(R.id.imageRes);
            event_name = itemView.findViewById(R.id.name);
            event_add = itemView.findViewById(R.id.address_item);
            imageView_event.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos=getLayoutPosition();
                    imageView_event.buildDrawingCache();
                   // int pos=imageView_event.getim
                    String n=event_name.getText().toString();
                    //String adn=event_add.getText().toString();
                    String adn=address[pos];
                    Intent i=new Intent(ctx,DetailsActivity.class);
                  //  i.putExtra("pos",pos);
                    i.putExtra("nn",n);
                    i.putExtra("aa",adn);
                    i.putExtra("ii",imgg[pos]);
                    ctx.startActivity(i);
                }
            });
        }

    }
}

