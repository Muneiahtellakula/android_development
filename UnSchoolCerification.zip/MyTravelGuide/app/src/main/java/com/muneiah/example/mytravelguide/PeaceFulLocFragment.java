package com.muneiah.example.mytravelguide;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;



public class PeaceFulLocFragment extends Fragment {
    String names[];
    String add[];
    String rat[];
    int im[];
    RecyclerView recyclerView;
    RecAdapter adapter;

    public PeaceFulLocFragment(){

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.place_list, container, false);


        recyclerView = rootView.findViewById(R.id.rec);
        im = new int[]{R.drawable.bramhasagar,
                R.drawable.palakondalu, R.drawable.gandikota,
                R.drawable.teluganga, R.drawable.darga,
                R.drawable.brundavan, R.drawable.machlipark};
        rat = new String[]{"4.2", "4.5", "4.3", "5.0", "4.0", "3.4", "0.5"};
        names = getResources().getStringArray(R.array.park_location);
        add = getResources().getStringArray(R.array.park_addrsess);
        adapter = new RecAdapter(getContext(), rat, im, names, add);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.addItemDecoration(new DividerItemDecoration(getContext(),1));
        recyclerView.setAdapter(adapter);
        return rootView;

    }
}
