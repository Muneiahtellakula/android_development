package com.muneiah.example.mytravelguide;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailsActivityForRest extends AppCompatActivity {
ImageView imageView;
TextView tt,rr,dd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_for_rest);
        imageView=findViewById(R.id.imageView_d);
        tt=findViewById(R.id.title_tv_de);
        rr=findViewById(R.id.rating_tv_de);
        dd=findViewById(R.id.address_tv_de);
        Intent i=getIntent();
        String resName=i.getStringExtra("n");
        String resrating=i.getStringExtra("r");
        String resadd=i.getStringExtra("a");
        int im=i.getIntExtra("im",0);
       imageView.setImageResource(im);
       rr.setText(resrating);
       tt.setText(resName);
       dd.setText(resadd);
    }
}