package com.muneiah.example.mytravelguide;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecAdapter extends RecyclerView.Adapter<RecAdapter.ViewHolder> {
    Context context;
    String rating[];
    int img[];
    String name[];
    String add[];

    public RecAdapter(Context context, String[] rating, int[] img, String[] name, String[] add) {
        this.context = context;
        this.rating = rating;
        this.img = img;
        this.name = name;
        this.add = add;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.list_item, parent, false));

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
     //  holder.address.setText("Address :"+add[position]);
        holder.nam.setText(name[position]);
        holder.rating.setText("Rating :"+rating[position]);
        holder.iv.setImageResource(img[position]);
    }

    @Override
    public int getItemCount() {
        return img.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView iv;
        TextView nam, address, rating;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            iv = itemView.findViewById(R.id.imageRes_listitem);
            nam = itemView.findViewById(R.id.name_tv);
            rating = itemView.findViewById(R.id.rating_bar_list);
            address = itemView.findViewById(R.id.address_list);
            iv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(context, "click", Toast.LENGTH_SHORT).show();
                    int pos=getLayoutPosition();
                    iv.buildDrawingCache();
                    String name=nam.getText().toString();
                   // String add=address.getText().toString();
                    String adda=add[pos];
                    String ra=rating.getText().toString();
                    Intent intent=new Intent(context,DetailsActivityForRest.class);

                    intent.putExtra("im",img[pos]);
                    intent.putExtra("n",name);
                    intent.putExtra("r",ra);
                    intent.putExtra("a",adda);
                    context.startActivity(intent);
                }
            });
        }
    }
}
