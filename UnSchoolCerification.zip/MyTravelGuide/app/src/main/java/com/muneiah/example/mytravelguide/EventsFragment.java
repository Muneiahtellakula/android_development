package com.muneiah.example.mytravelguide;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class EventsFragment extends Fragment {
String pls_adds[];
String placeName[];
int placeImg[];
PlacesAdapter adapter;
RecyclerView recyclerView_events;
    public EventsFragment(){

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.place_list, container, false);
        recyclerView_events=rootView.findViewById(R.id.rec);

        placeName=getResources().getStringArray(R.array.events_name);
        pls_adds=getResources().getStringArray(R.array.event_address);
        placeImg=new int[]{
                R.drawable.gandikota,
                            R.drawable.birdsevent,
                            R.drawable.milavaram,
                            R.drawable.campine,
                            R.drawable.jathara};
        adapter=new PlacesAdapter(getContext(),pls_adds,placeImg,placeName);
        recyclerView_events.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView_events.addItemDecoration(new DividerItemDecoration(getContext(),1));
        recyclerView_events.setAdapter(adapter);

        return rootView;
    }
}
