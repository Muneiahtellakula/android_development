package com.muneiah.example.mytravelguide;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class RestaurantsFragment extends Fragment {
    String names[];
    String add[];
    String rat[];
    int im[];
    RecyclerView recyclerView;
    RecAdapter adapter;

    public RestaurantsFragment() {
        // it requires an empty constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.place_list, container, false);
        recyclerView = rootView.findViewById(R.id.rec);
        im = new int[]{R.drawable.s2, R.drawable.raj, R.drawable.s2, R.drawable.raj, R.drawable.s2,
                R.drawable.raj, R.drawable.s2, R.drawable.raj, R.drawable.s2, R.drawable.raj, R.drawable.s2};

        rat = new String[]{"4.2", "4.5", "4.3", "5.0", "4.0", "3.4", "0.5", "4.5", "3.0", "5.0", "4.5"};
        names = getResources().getStringArray(R.array.restarent_name);
        add = getResources().getStringArray(R.array.restaurants_address);
        adapter = new RecAdapter(getContext(), rat, im, names, add);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.addItemDecoration(new DividerItemDecoration(getContext(),1));
        recyclerView.setAdapter(adapter);
        return rootView;
    }
}
