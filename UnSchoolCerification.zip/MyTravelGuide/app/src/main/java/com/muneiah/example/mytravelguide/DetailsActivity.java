package com.muneiah.example.mytravelguide;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailsActivity extends AppCompatActivity {
ImageView imageView_d;
TextView t1,t2;
    String pls_adds[];
    String placeName[];
    int placeImg[];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        imageView_d=findViewById(R.id.imageView_detils);
        t1=findViewById(R.id.text1_details);
        t2=findViewById(R.id.text2_details);
        placeName=getResources().getStringArray(R.array.events_name);
        pls_adds=getResources().getStringArray(R.array.event_address);
        Intent i=getIntent();
        int ni=i.getIntExtra("ii",0);
        String ai=i.getStringExtra("nn");
        String an=i.getStringExtra("aa");
        t1.setText(ai);
        t2.setText(an);
        imageView_d.setImageResource(ni);
    }
}