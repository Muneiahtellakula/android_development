package com.muneiah.example.mytravelguide;


import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class TemplesFragment extends Fragment {
    String temName[];
    String tepAdd[];
    int temImage[];
RecyclerView recyclerView;
PlacesAdapter adapter;
    public TemplesFragment(){

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.place_list, container, false);
        recyclerView=rootView.findViewById(R.id.rec);

            temName=getResources().getStringArray(R.array.temple_names);
            tepAdd=getResources().getStringArray(R.array.temple_address);
            temImage=new int[]{
                    R.drawable.thalapaka,
                    R.drawable.lalithadevi,
                    R.drawable.badri,
                    R.drawable.ga,
                    R.drawable.reli,
                    R.drawable.ma,
                    R.drawable.anji,
                    R.drawable.annamacharya};
        adapter=new PlacesAdapter(getContext(),tepAdd,temImage,temName);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.addItemDecoration(new DividerItemDecoration(getContext(),1));
        recyclerView.setAdapter(adapter);
              return rootView;
    }
}
